// Из контеста 2 
// создать класс, все операции с которым будут выводиться на консоль
#include <iostream>
#include <string>
#include <iomanip>

using namespace std; 

/* struct MyObject {

 std::string name;
 MyObject(std::string new_name) : name(new_name) {
  cout << "MyObject(" << std::quoted(name) << " created" << endl;
 }

 MyObject(const MyObject& other) :name(other.name) {
  cout << "MyObject being created as a copy of MyObject(" << std::quoted(other.name) << ")" << endl;
 }


 MyObject(const MyObject&& other) :name(std::move(other.name)) {
  cout << "MyObject being created as a moved value of MyObject(" << std::quoted(name) << ")" << endl;
 }

 
 const MyObject& operator = (const MyObject& other) {
  cout << "MyObject(" << name << ") being overwritten with a copied value of MyObject("<<&other<<")" << endl;
 }


 const MyObject& operator = (const MyObject&& other) {
  name = std::move(other.name);
  cout << "MyObject begin overwritten with a moved value of MyObject(" << name << ")," << endl;
 }
 
 ~MyObject() {
  cout << "MyObject("<< name<< ") destroied" << endl;

 }
}; */
class MyObject {
public:
    MyObject(std::string new_name) : name(new_name) {
        std::cout << "MyObject(\"" << name << "\") created" << std::endl;
    }

    MyObject(const MyObject &other) : name(other.name) {
        std::cout << "MyObject being created as a copy of MyObject(\"" << other.name << "\")" << std::endl;
    }

    MyObject(MyObject &&other) : name(std::move(other.name)) { 
        std::cout << "MyObject being created as a moved value of MyObject(\"" << name << "\")" << std::endl; 
    }

    const MyObject& operator=(const MyObject &other) {
        std::cout << "MyObject(\"" << name << "\") being overwritten with a copied value of MyObject(\"" << other.name << "\")" << std::endl;
        name = other.name;
        return *this;
    }

    const MyObject& operator=(MyObject &&other) {
 //       name = other.name;
        std::cout << "MyObject(\"" << name << "\") being overwritten with a moved value of MyObject(\"" << (other.name) << "\")" << std::endl;
        name = std::move(other.name);
        return *this;
    }

    ~MyObject() {
        std::cout << "MyObject(\"" << name << "\") destroied" << std::endl;
    }

private:
    std::string name;
};
// #include <iostream>
// #include <string>

// class MyObject {
// public:
//     MyObject(std::string new_name) : name(new_name) {
//         std::cout << name << " created" << std::endl;
//     }

//     MyObject(const MyObject &other) : name(other.name) {
//         std::cout << "MyObject being created as a copy of " << other.name << std::endl;
//     }

//     MyObject(MyObject &&other) : name(std::move(other.name)) {
//         std::cout << "MyObject being created as a moved value of " << other.name << std::endl;
//     }

//     const MyObject& operator=(const MyObject &other) {
//         if (this != &other) {
//             name = other.name;
//             std::cout << name << " being overwritten with a copied value of " << other.name << std::endl;
//         }
//         return *this;
//     }

//     const MyObject& operator=(MyObject &&other) {
//         if (this != &other) {
//             name = std::move(other.name);
//             std::cout << name << " being overwritten with a moved value of " << other.name << std::endl;
//         }
//         return *this;
//     }

//     ~MyObject() {
//         std::cout << name << " destroyed" << std::endl;
//     }

// private:
//     std::string name;
// };

int main() {
    MyObject obj1("hello");
    MyObject obj4(obj1);
    MyObject obj2("world");
    obj2 = obj1; // Copy assignment
    obj1.~MyObject();
    MyObject obj3 = std::move(obj2); // Move constructor
    obj3.~MyObject();
    obj1 = std::move(obj3); // Move assignment

    return 0;
}
