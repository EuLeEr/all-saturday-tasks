#include <iostream>
#include <string>
#include <vector>

using namespace std;

struct Settings {
    string key1;
    string key2;
    // Добавьте новые поля по мере необходимости
};

int main() {
//    Settings settings;

    vector<string> inputLines;
    string line;
    int i = 0;
    // Считываем строки из консоли
    while ((getline(cin, line)) && (i < 4)) {
        inputLines.push_back(line);
            i++;
        cout<< i << "\n";
    }

 /*    // Считываем поля в цикле
    for (const string& inputLine : inputLines) {
        size_t colonPos = inputLine.find(':');
        if (colonPos != string::npos) {
            string key = inputLine.substr(0, colonPos);
            string value = inputLine.substr(colonPos + 1);
            // Добавляем поля в структуру
            if (key == "ключ1") {
                settings.key1 = value;
            } else if (key == "ключ2") {
                settings.key2 = value;
            }
            // Добавьте новые условия для других полей
        }
    } */

    // Выводим значения полей
    cout << "Переменная-ключ1: " << settings.key1 << endl;
            cout << "Переменная-ключ2: " << settings.key2 << endl;
        // Выводите значения других полей по мере необходимости

        return 0;
}
